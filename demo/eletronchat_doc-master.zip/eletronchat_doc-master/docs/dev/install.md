# 安装
!> 请注意：本应用只能有`Linux`戓者`mac`这种类`Unix`的系统下运行。  
安装之前，请确保你的服务器已经安装
好`docker`和`git` 和 `docker-compose` ;如果不知道安装`docker`,请根据你的系统发行版查看[安装文档](https://docs.docker.com/install/linux/docker-ce/centos/)
来安装,安装`git`请使用自己的软件仓库源安装或者到[官方安装](https://git-scm.com/downloads)
下载。[`docker-compose`官方安装文档。](https://docs.docker.com/compose/)

* 下载源码: `git clone https://github.com/wuchuheng/electronchat_tp6.git`
* 切换到项目根目录并启动: `cd  electronchat_tp6; docker-compose up`

