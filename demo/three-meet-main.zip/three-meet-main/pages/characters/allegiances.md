# Allegiances

Rule

**Allegiances** are the folks you owe loyalty to, the groups you belong to and the principles by which you live. Pick three allegiances and rank them as major, medium and minor.

An **Allegiance** could be:

  + A principle, such as Justice or Power
  + An organisation or nation, such as the Thieves' Guild or The Men of Ulroth
  + A personal allegiance, perhaps to a family or individual
