# Classes

Rule

What do you bring to the table? What makes you useful? What is your power? **Classes** answer these questions.

The three classes are: [The Mighty](../../pages/classes/mighty.md), [The Cunning](../../pages/classes/cunning.md), and [The Wise](../../pages/classes/wise.md). Each has a number of archetypes, or sub-classes.
