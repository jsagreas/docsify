# Backgrounds

Rule

Where did you come from? How did you get here? How do you make a living? **Backgrounds** answer these questions and more.

Each **Backgrounds** has a number specialities.
