# Moves

Rule

Movement in combat uses the abstract rules for [Distance](../../pages/rules/distance.md). On your **Turn**, you can:

 * Use your [Move](../../pages/combat/moves.md) to go somewhere **Nearby**
 * Use the [Dash](../../pages/combat/actions.md#dash) action with your [Move](../../pages/combat/moves.md) to reach somewhere **Far-Away**
 * Take 3 [Moves](../../pages/combat/moves.md) to go anywhere **Distant**

Your movement can include jumping, climbing, and swimming.
