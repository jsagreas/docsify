# Reactions

Rule

Some features and spells let you trigger a **Reaction** at any time, not just on your **Turn**:

  + You can only take one **Reaction** per **Round**.

You can make the following **Reactions** by default:

<section class="small summaries">

<section class="summary">

## Opportunity Attack

Reaction

You can make an **Opportunity Attack** when a creature leaves an area [Close](../../pages/rules/distance.md) to you. You can make one melee attack against the creature.

</section>

</section>
