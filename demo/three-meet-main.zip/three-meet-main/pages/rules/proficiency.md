# Proficiency

Rule

**Proficiency** is a bonus representing your expertise:

 * Add your **Proficiency** to rolls you are proficient with.
 * You can be proficient in rolls related to specific weapons, skills, [Saves](../../pages/rules/rolling/saves.md), or tools.
 * You can only add **Proficiency** to any single die roll once.
 * Your **Proficiency** increases as your level increases.
