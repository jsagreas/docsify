# Rolling

Rule

In Three Meet you'll be asked to roll d4s, d8s, d10s, d12s, d20s and d100s. There are three main rolls: [Checks](../../pages/rules/rolling/checks.md), [Saves](../../pages/rules/rolling/saves.md), and [Attacks](../../pages/combat/attacks.md).
