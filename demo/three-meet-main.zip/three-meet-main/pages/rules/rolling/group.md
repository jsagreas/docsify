# Group Checks

Rule

You can make a **Group Check** when a number of characters are trying to accomplish something as a group.

To make a **Group Check**, everyone in the group makes a [Check](../../pages/rules/rolling/checks.md). If at least half the group succeeds, the whole group succeeds.
Otherwise, the group fails.

A **Group Check** can use a single [Skill](../../pages/characters/skills.md), or multiple [Skills](../../pages/characters/skills.md) depending on the players or GM.
