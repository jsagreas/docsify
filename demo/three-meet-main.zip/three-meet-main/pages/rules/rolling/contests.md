# Contests

Rule

Sometimes your efforts are directly opposed by another creature. When this happens you can make a **Contest**:

  1. Both participants make a [Check](../../pages/rolling/checks.md)
  2. Compare the totals:
    1. If your total is greater than your opponent's you win the **Contest**
    2. If your total is less than your opponent's you lose
    3. If your totals are equal the situation remains unchanged
