# Rests

Rule

The world is a trying place, and adventurers easily become weary. They need rest–time to sleep and eat, tend their wounds, refresh their minds and spirits.

A rest is a 8 hours of extended downtime during which a character sleeps or performs light activity.

A rest confers the following benefits:

  * Regain all [Stamina](../../pages/combat/stamina.md)
  * Regain expended [Class](../../pages/classes/index.md) and [Background](../../pages/backgrounds/index.md) features
