
本文档由开源文档工具[docsify](https://github.com/docsifyjs/docsify)生成  
由`markdown`语言编写  

本文档网站为静态网站，可部署到本地预览

1. 下载源文件到本地
    ```shell
    git clone git@github.com:YxxY/docs.git 
    ```
2. 起一个本地静态服务 (eg: 以python举例)
    ```shell
    cd docs && python -m SimpleHTTPServer 3000
    ``` 
3. 打开浏览器，查看 [http://127.0.0.1:3000](http://127.0.0.1:3000)
