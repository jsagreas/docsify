各种常识的积累和分享
<center>

![Enough](img/enough.png)
</center>