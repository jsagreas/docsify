关于开源许可证，几个用的最广的许可证说明，借用阮一峰的一张非常流行的图来展示

<center>

![license](img/license.png)
</center>

最宽松的是 MIT license  
比较推荐的是GPL license

关于如何选一个合适的license，可参考  
- [如何为自己的项目选一个许可证](http://www.gnu.org/licenses/license-recommendations.html)
- [License 汇总说明](http://www.gnu.org/licenses/license-list.html)