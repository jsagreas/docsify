![logo](static/icon.png)

# 蓝笔头

> Just write it down 🚀

- 年纪越大记性越来越差了
- 最好的输入就是输出
- Happy Learning

[GitHub](https://github.com/YxxY/docs)
[Get Started](README)