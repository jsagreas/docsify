linux 操作基本通过shell命令，也是学习的重点  
没有捷径，只有总结归纳，熟能生巧  

初学者可参考 [Linux 命令大全](http://www.runoob.com/linux/linux-command-manual.html)

命令通常会包含许多命令行选项，不需要强记，用的多了自然记得住，或者知道在哪儿查看也可以

> `<COMMAND> -h | --help` 查看命令基本介绍

> `man <COMMAND>` 查看命令详细介绍
