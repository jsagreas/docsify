配置 `upstream`指令完成负载均衡的配置
