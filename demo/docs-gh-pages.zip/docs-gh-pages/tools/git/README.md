linus一周完成了Git的数据模型设计——[一周的工程](https://lkml.org/lkml/2005/4/6/121)， 随后git越来越普及，越来越火。  
这年头程序员要是不会使用git都不好意思跟人打招呼。
然而如同《皇帝的新衣》，Git太流行了，大家都不会或者不好意思说它“难学”，“难用”。
哪怕事实上它对于很多人来说就是一堆死记硬背的命令的集合。    

实际上Git没那么简单，当然也没那么难，前提是真的了解它的原理。

贴一篇很有启发性的老文章[Git比你想象的简单](http://nfarina.com/post/9868516270/git-is-simpler)


主要参考内容：
- [Pro Git](https://progit.bootcss.com/#_getting_started)
- [Pro Git v2](https://git-scm.com/book/zh/v2/%E8%B5%B7%E6%AD%A5-%E5%85%B3%E4%BA%8E%E7%89%88%E6%9C%AC%E6%8E%A7%E5%88%B6)
- [万能的stackoverflow](https://stackoverflow.com)