Python提供高层模块 [multiprocessing](https://docs.python.org/3/library/threading.html)来实现多进程  
该模块提供了和多线程类型的 API, 当多进程还提供了额外的接口供使用, 例如 `Pool`

