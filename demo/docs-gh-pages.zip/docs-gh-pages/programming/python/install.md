## windows 安装
- 官网下载安装包
- 安装时选择安装 pip
- 将 python可执行文件添加到环境变量
- 如果同时安装多个版本，eg：同时安装 python2.7和python3.7
    - 需要将 python3.7 的可执行文件 python.exe 重命名为 python3.exe
    - 执行命令 `python3 -m pip install -U pip` 重新安装 python3 的 pip
