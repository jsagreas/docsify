Python 有一个"自带电池"(batteries included)的哲学理念, 说的就是拥有丰富的内置库可供使用.
