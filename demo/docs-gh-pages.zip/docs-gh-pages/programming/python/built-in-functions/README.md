Python 提供了一批[内置函数](https://docs.python.org/3/library/functions.html), 可以全局调用  

