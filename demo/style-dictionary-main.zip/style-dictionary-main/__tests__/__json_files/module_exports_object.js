module.exports = {
  "foo": "bar",
  "bar": "{foo}"
}
