module.exports = {
  base: { value: "{color.core.grey.100.value}" },
  secondary: { value: "{color.core.grey.80.value}" },
  link: { value: "{color.brand.primary.base.value}" },
  inverse: {
    base: { value: "#fff" }
  }
}