module.exports = {
  '1': { value: 0.5 },
  '2': { value: 1 },
  '3': { value: 2 },
  '4': { value: 3.5 },
  '5': { value: 5 },

  base: { value: '{size.padding.1.value}' },
  large: { value: '{size.padding.2.value}' },
}