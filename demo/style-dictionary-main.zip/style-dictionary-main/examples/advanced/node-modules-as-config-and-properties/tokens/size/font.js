module.exports = {
  '1': { value: 0.75 },
  '2': { value: 0.875 },
  '3': { value: 1 },
  '4': { value: 1.25 },
  '5': { value: 1.75 },
  '6': { value: 2.5 },

  base: { value: '{size.font.3.value}' },
  large: { value: '{size.font.4.value}' },
}