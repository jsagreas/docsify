// Look! No namespaces!
module.exports = {
  width: {
    base: { value: 0.125 }
  },
  radius: {
    base: { value: 0.25 }
  }
}