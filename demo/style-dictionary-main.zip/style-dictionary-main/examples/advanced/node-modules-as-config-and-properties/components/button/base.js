module.exports = {
  padding: { value: '{size.padding.base.value}' },
  'font-size': { value: '{size.font.large.value}' }
}