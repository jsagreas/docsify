module.exports = {
  component: {
    button: require('./button')
  }
}