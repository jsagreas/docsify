//
//  UIButton+StyleDictionary.h
//  Pods
//
//  Created by Banks, Daniel on 1/28/17.
//
//

#import <UIKit/UIKit.h>
#import "UIColor+StyleDictionary.h"

@interface UIButton (StyleDictionary)

+ (UIButton *)styleDictionaryButton;

@end
