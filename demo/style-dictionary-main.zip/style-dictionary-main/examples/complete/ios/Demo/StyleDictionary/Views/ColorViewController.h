//
//  ColorViewController.h
//  StyleDictionaryExample
//
//  Created by Banks, Daniel on 1/21/17.
//  Copyright © 2017 Danny Banks. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <StyleDictionary/StyleDictionary.h>
#import "BaseColorViewController.h"
#import "TextColorViewController.h"
#import "BackgroundColorsViewController.h"

@interface ColorViewController : UIViewController

@end
