# test

```javascript
function getAdder(int $x): int 
{
    return 123;
}
```

:100:
支持 Vue 的写法
```html
<ul>
  <li v-for="i in 3">Item {{ i }}</li>
</ul>
```
<ul>
  <li v-for="i in 3">Item {{ i }}</li>
</ul>

![logo](https://docsify.js.org/_media/icon.svg ':size=100')

## 关于 BackLink 的写法

采用双联写法，兼容 Obsidian 
`[[about]]`

`asdjkasdjkasd` 

asdahsk[[about]]

代码块应用

`[[about/hello.md ':include :type=code']]`



```dataviewjs
```
?> _TODO_ 完善示例

[link](/demo ':target=_blank')

<details>
<summary>自我评价（点击展开）</summary>

- Abc
- Abc

</details>

```html
<!-- 在docsify中隐藏，在其他地方显示（如GitHub）。 -->
<p v-if="false">Text for GitHub</p>

<!-- Sequenced content (i.e. loop)-->
<ul>
  <li v-for="i in 3">Item {{ i }}</li>
</ul>

<!-- JavaScript expressions -->
<p>2 + 2 = {{ 2 + 2 }}</p>
```




<!-- 在docsify中隐藏，在其他地方显示（如GitHub）。 -->
<p v-if="false">Text for GitHub</p>

<!-- Sequenced content (i.e. loop)-->
<ul>
  <li v-for="i in 3">Item {{ i }}</li>
</ul>

<!-- JavaScript expressions -->
<p>2 + 2 = {{ 2 + 2 }}</p>

---

- [ ] 具有 DataView 功能
- [ ] 建立 Warehorse 能力
- [ ] 提供组件开发的能力
- [ ] 预览组件
- [ ] 插件机制