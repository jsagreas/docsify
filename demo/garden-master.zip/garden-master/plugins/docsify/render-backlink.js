export default function BackLink(options) {
  return (hook, vm) => {
    hook.beforeEach(function(markdown) {
      // ...
      const linkReg = /^(.*)(?!`)(\[\[)(.*)(\]\])(?!`)(.*)$/gim;
      return markdown.replace(linkReg, '$1[backlink $3]($3)$5');
    });
  };
}
