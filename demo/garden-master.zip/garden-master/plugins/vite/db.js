import fs from 'fs';
import path from 'path';

// 解析数据信息
function loadWareHouse() {}

async function travelAllData(src, root = [], depth = 0) {
  if (!src) return;
  const stat = await fs.statSync(src);
  if (stat.isDirectory()) {
    const subDir = await fs.readdirSync(src);
    subDir.forEach(async (item) => {
      const stat = await fs.statSync(path.resolve(src, item));
      if (stat.isDirectory()) {
        console.log(item);
        root.push({
          path: path.relative(src, item),
          type: 'dir',
          children: await travelAllData(
            path.join(src, item),
            item.children ?? [],
            depth + 1
          ),
        });
        // return ;
      } else if (stat.isFile()) {
        const linkPath = path.relative(process.cwd(), item);
        const abspath = path.join(src, item);
        root.push({
          path: linkPath,
          type: 'file',
          content: fs.readFileSync(abspath).toString(),
          children: null,
        });
      }
    });
    return root;
  }
}
// dataview转换数据信息到markdown
export default function warehouse({ root = '', gateway = [] }) {
  // 进入路径
  root = path.resolve(process.cwd(), root);
  let data = travelAllData(root);

  const virtualModuleId = 'virtual:house';
  const resolvedVirtualModuleId = '\0' + virtualModuleId;
  return {
    name: 'vite-plugin-warehouse',
    resolve(id) {
      if (id === virtualModuleId) return resolvedVirtualModuleId;
    },
    load(id) {
      if (id === resolvedVirtualModuleId) {
        return `export default ${warehouse.toString()}$`;
      }
    },
    transform(code, id) {
      console.log(id);
    },
  };
}
