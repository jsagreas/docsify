"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DB = void 0;
var warehouse_1 = require("warehouse");
var file_model_1 = require("./model/file.model");
exports.DB = new warehouse_1.default().model('file', file_model_1.FileModel);
exports.DB.insert({
    file: 'asd',
}, function (data) {
    console.log(data);
}).then(function (data) {
    console.log(data);
});
