

import type { FileModelInterface } from "../model/file.model";
import fs from 'fs';
async function travelAllFile(
    src:string,
    root:FileModelInterface[],
    ignoreFn:(file:FileModelInterface)=>boolean|void):Promise<FileModelInterface[]> {

    if (!src) return root;
    const stat:Awaited<fs.Stats> =await fs.statSync(src)
    if(stat.isDirectory()) {
        // 如果是目录的情况
        const subDir:Awaited<String[]> =await fs.readdirSync(src);
                
        return root.concat(subDir.map(createRoot));
    };
    return root;

}
function createRoot() {

}