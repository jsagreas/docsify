import SchemaType from 'warehouse/dist/schematype';

export interface FileModelInterface {}

export class FileModel extends SchemaType<FileModelInterface> {
  constructor(name: string, options = {}) {
    super(name, Object.assign(options));
  }
}
