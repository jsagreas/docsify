import Database from 'warehouse';

import { FileModel } from './model/file.model';
import Model from 'warehouse/dist/model';

export const DB: Model = new Database().model('file', FileModel);

DB.insert(
  {
    file: 'asd',
  },
  (data: Model) => {
    console.log(data);
  }
).then((data:Model)=>{
    console.log(data);
});
