import { defineConfig, loadEnv } from 'vite';
import copy from 'rollup-plugin-copy';
import warehouse from './plugins/vite/db';
export default defineConfig(({ mode, command }) => {
  const env = loadEnv(mode, process.cwd(), '');
  return {
    // vite config

    plugins: [
      copy({
        targets: [
          {
            src: 'docs/*',
            dest: 'dist/docs/',
          },
        ],
        hook: 'writeBundle', // 钩子，插件运行在rollup完成打包并将文件写入磁盘之前
        verbose: true, // 在终端进行console.log
      }),
      warehouse({
        root: './docs',
        gateway: [],
      }),
    ],
  };
});
