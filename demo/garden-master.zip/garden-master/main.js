//cdn.jsdelivr.net/npm/docsify@4
// import '';
import 'docsify/lib/themes/vue.css';
import BackLink from './plugins/docsify/render-backlink';

window.$docsify = {
  el: '#app',

  name: 'CouriourC Garden💡',
  loadSidebar: true,
  loadNavbar: true,
  executeScript: true,
  basePath: '/docs/',
  nativeEmoji: true,
  coverpage: true,
  // Relative path enabled
  relativePath: true,
  mergeNavbar: true,
  repo: 'couriourc/garden',
  plugins: [BackLink({})],
  markdown: {
    renderer: {
      link(href, title, text) {
        if (text.startsWith('backlink')) {
          return `<a href="#${href}" class="backlink" title="${title}">${text.replace(
            'backlink',
            ''
          )}</a>`;
        }
        return this.origin.link.apply(this, arguments);
      },
    },
  },
  // 字数统计
  count: {
    countable: true,
    fontsize: '0.9em',
    color: 'rgb(90,90,90)',
    language: 'chinese',
  },

  // 全文搜索
  search: {
    paths: 'auto',
    placeholder: 'Type to search',
    noData: 'No Results!',
    depth: 6,
  },

  vueGlobalOptions: {
    data() {
      return {
        count: 0,
      };
    },
  },
  vueMounts: {
    '#counter': {
      data() {
        return {
          count: 0,
        };
      },
      created() {
        console.log(this);
      },
    },
  },
};

(async () => {
  await import('docsify');

  await import('docsify/lib/plugins/emoji.min.js');

  // S Markdown Render
  await import('prismjs');
  // S 数学公式
  await import('katex/dist/katex.min.css');
  await import('katex/dist/katex.min');
  await import('docsify-katex/dist/docsify-katex.js');

  // E 数学公式
  await import('marked');

  // E Markdown Render
  await import('docsify-count/dist/countable');

  await import('docsify-copy-code/dist/docsify-copy-code.min');

  // S Core Plugins
  // S 搜索插件
  await import('docsify/lib/plugins/search.min.js');
  // E 搜索插件
  // S Edit On Github
  await import('docsify-edit-on-github');
  // E Edit On Github

  // E Core Plugins

  await import('./plugins/docsify/render-backlink');
})();



