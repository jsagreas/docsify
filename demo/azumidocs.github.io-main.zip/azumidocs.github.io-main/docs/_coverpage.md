# Azumi Documentation

[Documentation](/docs.md)
[Guide](/guide.md)

![color](#)