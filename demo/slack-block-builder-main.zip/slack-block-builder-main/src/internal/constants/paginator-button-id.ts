export enum PaginatorButtonId {
  Next = 'next',
  Previous = 'previous',
}
