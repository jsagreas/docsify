export enum ButtonStyle {
  Danger = 'danger',
  Primary = 'primary',
}
