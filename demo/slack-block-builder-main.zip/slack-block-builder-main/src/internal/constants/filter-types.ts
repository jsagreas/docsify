export enum FilterType {
  Im = 'im',
  Mpim = 'mpim',
  Private = 'private',
  Public = 'public',
}
