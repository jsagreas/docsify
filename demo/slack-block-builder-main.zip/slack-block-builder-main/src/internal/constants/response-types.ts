export enum ResponseType {
  Ephemeral = 'ephemeral',
  InChannel = 'in_channel',
}
