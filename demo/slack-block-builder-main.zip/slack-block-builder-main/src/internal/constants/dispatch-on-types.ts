export enum DispatchOnType {
  OnEnterPressed = 'on_enter_pressed',
  OnCharacterEntered = 'on_character_entered',
}
