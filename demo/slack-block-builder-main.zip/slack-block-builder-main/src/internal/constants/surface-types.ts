export enum SurfaceType {
  HomeTab = 'home',
  Modal = 'modal',
  WorkflowStep = 'workflow_step',
}
