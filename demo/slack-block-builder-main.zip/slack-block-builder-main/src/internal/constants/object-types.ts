export enum ObjectType {
  Text = 'plain_text',
  Markdown = 'mrkdwn',
}
