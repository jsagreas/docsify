export enum FileType {
  Remote = 'remote',
}
