export enum ComponentUIText {
  Next = 'Next',
  Previous = 'Previous',
  More = 'More',
  Close = 'Close',
}
