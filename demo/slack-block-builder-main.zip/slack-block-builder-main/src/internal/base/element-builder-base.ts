import { Builder } from '../lib/builder';

export abstract class ElementBuilderBase extends Builder {
}
