import { Builder } from '../lib/builder';

export abstract class BitBuilderBase extends Builder {
}
