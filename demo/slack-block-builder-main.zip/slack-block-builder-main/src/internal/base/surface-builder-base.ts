import { Builder } from '../lib/builder';

export abstract class SurfaceBuilderBase extends Builder {
}
