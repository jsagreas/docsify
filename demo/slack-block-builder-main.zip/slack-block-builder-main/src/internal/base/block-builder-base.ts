import { Builder } from '../lib/builder';

export abstract class BlockBuilderBase extends Builder {
}
