export abstract class CompositionObjectBase {
}
