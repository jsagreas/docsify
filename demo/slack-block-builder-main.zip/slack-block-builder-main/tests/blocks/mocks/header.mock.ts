import { HeaderBuilder } from '../../../src/blocks/header';

export const params = {
  text: 'text',
  blockId: 'blockId',
};

export const mock = new HeaderBuilder(params);
