import { DividerBuilder } from '../../../src/blocks/divider';

export const params = {
  blockId: 'blockId',
};

export const mock = new DividerBuilder(params);
