import { ActionsBuilder } from '../../../src/blocks/actions';

export const params = {
  blockId: 'blockId',
};

export const mock = new ActionsBuilder(params);
