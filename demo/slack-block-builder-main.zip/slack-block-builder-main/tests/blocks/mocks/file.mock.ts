import { FileBuilder } from '../../../src/blocks/file';

export const params = {
  externalId: 'externalId',
  blockId: 'blockId',
};

export const mock = new FileBuilder(params);
