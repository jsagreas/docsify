import { SectionBuilder } from '../../../src/blocks/section';

export const params = {
  text: 'text',
  blockId: 'blockId',
};

export const mock = new SectionBuilder(params);
