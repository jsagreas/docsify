import { InputBuilder } from '../../../src/blocks/input';

export const params = {
  label: 'label',
  blockId: 'blockId',
  hint: 'hint',
};

export const mock = new InputBuilder(params);
