import { ContextBuilder } from '../../../src/blocks/context';

export const params = {
  blockId: 'blockId',
};

export const mock = new ContextBuilder(params);
