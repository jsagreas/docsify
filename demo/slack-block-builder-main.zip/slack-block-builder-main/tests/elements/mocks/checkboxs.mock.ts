import { CheckboxesBuilder } from '../../../src/elements/checkboxes';

export const params = {
  actionId: 'actionId',
};

export const mock = new CheckboxesBuilder(params);
