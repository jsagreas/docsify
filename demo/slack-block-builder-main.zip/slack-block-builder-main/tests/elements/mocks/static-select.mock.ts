import { StaticSelectBuilder } from '../../../src/elements/static-select';

export const params = {
  placeholder: 'placeholder',
  actionId: 'actionId',
};

export const mock = new StaticSelectBuilder(params);
