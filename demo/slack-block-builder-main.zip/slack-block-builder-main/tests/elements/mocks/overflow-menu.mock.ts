import { OverflowMenuBuilder } from '../../../src/elements/overflow-menu';

export const params = {
  actionId: 'actionId',
};

export const mock = new OverflowMenuBuilder(params);
