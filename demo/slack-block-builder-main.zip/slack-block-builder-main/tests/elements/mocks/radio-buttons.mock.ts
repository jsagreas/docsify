import { RadioButtonsBuilder } from '../../../src/elements/radio-buttons';

export const params = {
  actionId: 'actionId',
};

export const mock = new RadioButtonsBuilder(params);
