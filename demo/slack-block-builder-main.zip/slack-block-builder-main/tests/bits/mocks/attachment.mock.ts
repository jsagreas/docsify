import { AttachmentBuilder } from '../../../src/bits/attachment';

export const params = {
  color: 'color',
  fallback: 'fallback',
};

export const mock = new AttachmentBuilder(params);
