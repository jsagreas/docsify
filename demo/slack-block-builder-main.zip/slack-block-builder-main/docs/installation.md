# Installation

Straightforward. Just like you'd expect. No magic. Just NPM. But the best part? You're only downloading **Block Builder**. No dependencies, no problems.

### Using NPM: 

``` bash
npm install --save slack-block-builder
```

### Using Yarn: 

``` bash
yarn add slack-block-builder
```