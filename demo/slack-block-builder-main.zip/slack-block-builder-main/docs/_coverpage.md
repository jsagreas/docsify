
![logo](resources/images/logo-vertical.png)

<p align="center">
    <h3 align="center">Welcome to the docs site for Block Builder.</h3>
</p>

<p align="center">
    Your Slack apps are about to get a lot more <em>maintainable</em>.
</p>

[View Docs](#start)
[Go to GitHub](https://github.com/raycharius/slack-block-builder/)

![color](#f0f0f0)
