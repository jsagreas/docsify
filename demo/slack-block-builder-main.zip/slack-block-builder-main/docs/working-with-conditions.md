# Working With Conditions 

Please note that this section of the documentation is still a work in progress. Please see [this section of the README on GitHub](https://github.com/raycharius/slack-block-builder#working-with-inline-conditionals) for more information until the docs have been updated to reflect changes in version 2.4.0.
