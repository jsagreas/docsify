
## 5.0.6 - Mon May 22 2023

### Fixed

- Published to incorrect package manager

## 5.0.5 - Mon May 22 2023

### Fixed

- Namespace issue - wrapped the script into its own local environment to avoid clashing
- Addition into Docsify.js plugin list more inline with the documentation
