# **sidebarFooter** plugin<br>for docsify.js

Add your footer to the sidebar (or anywhere)

[Find it on Github](https://github.com/markbattistella/docsify-sidebarFooter)
[Read more](#docsifyjs-sidebar-footer)
[npm link](https://www.npmjs.com/package/@markbattistella/docsify-sidebarfooter)
