export const latexTagName = 'docsify-latex';
export const latexBackTagName = 'docsify-latex-back';

export const latexTagDisplayAttrName = 'display';
