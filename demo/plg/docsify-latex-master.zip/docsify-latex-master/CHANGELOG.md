# Change Log

## 0.5.x

*2022-09-26*

- Enhance cross-reference
- Code refactor & Fixes

## 0.4.x

*2022-09-24*

- Add beforeInitFunc option
- inline mode overflowScroll support
- Code refactor & Fixes

## 0.3.0

*2022-09-24*

- Add overflowScroll option for display mode

## 0.2.x

*2022-09-22*

- Support cross-reference jump
- Code refactor & Fixes

## 0.1.x

*2022-09-18*

- Support custom options
- Code refactor & Fixes

## 0.0.2 - 0.0.5

*2022-09-17*

- Code refactor & Fixes

## 0.0.1

*2022-09-17*

- Initial release
