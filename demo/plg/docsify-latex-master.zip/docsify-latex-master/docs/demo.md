# Demo Projects

- [docsify-latex](/) - Documentation pages for this project.
- [Notes-ML-AndrewNg](https://scruel.github.io/Notes-ML-AndrewNg) - A notes project for machine learning course on Coursera taught by Andrew Ng.
