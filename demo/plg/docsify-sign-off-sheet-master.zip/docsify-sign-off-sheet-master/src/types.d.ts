declare global {
  interface Window {
    $docsify: any;
  }
}
