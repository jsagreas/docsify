# Default Slide

Here is what a default slide looks like.

There are two sections, and they both have 50% of the page width.

![Random Kitten Image](https://placekitten.com/300/400)

<!-- slide:break -->

# 

I have added: 

```
<!-- slide:break -->
```

in my markdown to separate these two sections.

![Random Kitten Image](https://placekitten.com/300/350)
