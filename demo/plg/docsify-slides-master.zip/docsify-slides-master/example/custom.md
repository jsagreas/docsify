# Custom Width Separator

You can adjust the width separating the left and right side:

```
<!-- slide:break-70 -->
```

![Random Kitten Image](https://placekitten.com/350/400)

<!-- slide:break-70 -->

# 

You can see now the first section takes up 70% of the page width.

> **NOTE:** I use a blank header tag (`#`) to keep the height of the sections the same.

![Random Kitten Image](https://placekitten.com/200/300)
