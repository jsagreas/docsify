# Responsive Design

On screens less than 768px, the two column layout collapses.

## Cat 1

![Random Kitten Image](https://placekitten.com/400/399)


<!-- slide:break -->

# 

(Try it out!)

# Cat 2

![Random Kitten Image](https://placekitten.com/400/400)
