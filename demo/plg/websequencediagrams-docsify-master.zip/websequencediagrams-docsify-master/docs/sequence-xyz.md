# An arbitary diagram

```websequencediagrams
title Arbitary

Alice->Bob: Authentication Request
note right of Bob: Bob thinks about it
Bob->Alice: Authentication Response

A->+B: text
B-->-A: text
```
