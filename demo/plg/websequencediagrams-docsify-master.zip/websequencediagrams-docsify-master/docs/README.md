# websequencediagrams-docsify

A plugin to render web sequence diagrams -- Just like that!

```websequencediagrams

title Foo-Bar!

Alice->Bob: Authentication Request
note right of Bob: Bob thinks about it
Bob->Alice: Authentication Response
```

And yet another diagram

```websequencediagrams

title Bar-Foo!

Alice->Mark: A very un-reasonable request
Mark->Alice: Sorry I can't fulfil it as it is hurting my values, Thank you!
Alice->Mark: Wow! I thought humans don't think anymore
```