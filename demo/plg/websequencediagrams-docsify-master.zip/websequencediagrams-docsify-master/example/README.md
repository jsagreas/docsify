# websequencediagrams-docsify

A plugin to render web sequence diagrams -- Just like that!

```websequencediagrams

title Foo-Bar!

Alice->Bob: Authentication Request
note right of Bob: Bob thinks about it
Bob->Alice: Authentication Response
```
