declare interface Window {
	nomnoml?: Nomnoml
	graphre?: Graphre
	$docsify?: {
		nomnoml?: UserConfig
		plugins?: Function[]
	}
}
