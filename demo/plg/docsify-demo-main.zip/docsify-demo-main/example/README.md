<p>Here are some tests.</p>

```html preview
<b style="color: red;">Inline styles are supported too.</b>
```

```html preview
<b style="color: blue;">Test.</b>
```

```html preview
<div>
    <span>
        <b style="color: blue;">Test.</b>
    </span>
</div>
```
