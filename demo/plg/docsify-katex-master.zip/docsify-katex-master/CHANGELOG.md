# `docsify-katex` Changelog

## v1.4.2

2019.03.20

- Fixed `\neq`, `\ne` etc.