<!-- markdownlint-disable MD002 MD022 -->

```charty
{
  "title":   "Column chart",
  "caption": "With a caption",
  "type":    "column",
  "options": {
	"legend":  true,
    "labels":  true,
    "numbers": true
  },
  "data": [
	{ "label": "2012", "value": [199, 100] },
	{ "label": "2014", "value": [85, 217] }
  ]
}
```

## Raw code

```json
{
  "title":   "Column chart",
  "caption": "With a caption",
  "type":    "column",
  "options": {
	"legend":  true,
    "labels":  true,
    "numbers": true
  },
  "data": [
	{ "label": "2012", "value": [199, 100] },
	{ "label": "2014", "value": [85, 217] }
  ]
}
```
