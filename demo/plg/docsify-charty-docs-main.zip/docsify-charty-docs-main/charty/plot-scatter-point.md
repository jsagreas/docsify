<!-- markdownlint-disable MD002 MD022 -->

```charty
{
  "title":   "Scatter chart",
  "caption": "With a caption",
  "type":    "scatter",
  "options": {
	"legend":  true,
    "labels":  true,
    "numbers": true
  },
  "data": [
	  { "label": "2010",  "value": [ 10, 90, 20, 80, 30, 70, 20 ] },
	  { "label": "2015",  "value": [ 245, 765, 467, 70, 443, 242, 30 ] },
	  { "label": "2020",  "value": [ 995, 33, 85, 650, 56, 200 ] }
  ]
}
```

## Raw code

```json
{
  "title":   "Scatter chart",
  "caption": "With a caption",
  "type":    "scatter",
  "options": {
	"legend":  true,
    "labels":  true,
    "numbers": true
  },
  "data": [
	  { "label": "2010",  "value": [ 10, 90, 20, 80, 30, 70, 20 ] },
	  { "label": "2015",  "value": [ 245, 765, 467, 70, 443, 242, 30 ] },
	  { "label": "2020",  "value": [ 995, 33, 85, 650, 56, 200 ] }
  ]
}
```
