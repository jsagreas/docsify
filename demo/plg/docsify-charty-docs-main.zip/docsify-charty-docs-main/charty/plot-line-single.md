<!-- markdownlint-disable MD002 MD022 -->

```charty
{
  "title":   "Line chart",
  "caption": "With a caption",
  "type":    "line",
  "options": {
	"legend":  true,
    "labels":  true,
    "numbers": true
  },
  "data": [
	  { "label": "Features",  "value": [ 10, 90, 20, 80, 60, 70, 30, 40, 0 ] }
  ]
}
```

## Raw code

```json
{
  "title":   "Line chart",
  "caption": "With a caption",
  "type":    "line",
  "options": {
	"legend":  true,
    "labels":  true,
    "numbers": true
  },
  "data": [
	  { "label": "Features",  "value": [ 10, 90, 20, 80, 60, 70, 30, 40, 0 ] }
  ]
}
```
