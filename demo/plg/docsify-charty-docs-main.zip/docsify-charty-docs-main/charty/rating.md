<!-- markdownlint-disable MD002 MD022 -->

```charty
{
  "title":   "Review chart",
  "caption": "With a caption",
  "type":    "review",
  "options": {
    "labels":  true,
    "numbers": true
  },
  "data": [
    { "label": "2010", "value": 10 },
	{ "label": "2012", "value": 20 },
	{ "label": "2014", "value": 30 }
  ]
}
```

## Raw code

```json
{
  "title":   "Review chart",
  "caption": "With a caption",
  "type":    "review",
  "options": {
    "labels":  true,
    "numbers": true
  },
  "data": [
    { "label": "2010", "value": 10 },
	{ "label": "2012", "value": 20 },
	{ "label": "2014", "value": 30 }
  ]
}
```
