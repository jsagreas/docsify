<!-- markdownlint-disable MD002 MD022 -->

```charty
{
  "title":   "Bar chart",
  "caption": "With a caption",
  "type":    "bar",
  "options": {
	"legend":  true,
    "labels":  true,
    "numbers": true
  },
  "data": [
	{ "label": "2012", "value": [199, 100] },
	{ "label": "2014", "value": [85, 217] }
  ]
}
```

## Raw code

```json
{
  "title":   "Bar chart",
  "caption": "With a caption",
  "type":    "bar",
  "options": {
	"legend":  true,
    "labels":  true,
    "numbers": true
  },
  "data": [
	{ "label": "2012", "value": [199, 100] },
	{ "label": "2014", "value": [85, 217] }
  ]
}
```
