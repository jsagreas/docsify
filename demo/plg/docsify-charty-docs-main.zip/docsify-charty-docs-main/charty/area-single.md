<!-- markdownlint-disable MD002 MD022 -->

```charty
{
  "title":   "Area chart",
  "caption": "With a caption",
  "type":    "area",
  "options": {
	"legend":  true,
    "labels":  true,
    "numbers": true
  },
  "data": [
    {
		"label": "2010",
		"value": [120, 23, 45, 34, 52, 43, 59, 40]
	 }
  ]
}
```

## Raw code

```json
{
  "title":   "Area chart",
  "caption": "With a caption",
  "type":    "area",
  "options": {
	"legend":  true,
    "labels":  true,
    "numbers": true
  },
  "data": [
    {
		"label": "2010",
		"value": [120, 23, 45, 34, 52, 43, 59, 40]
	 }
  ]
}
```
