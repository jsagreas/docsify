<!-- markdownlint-disable MD002 MD022 -->

```charty
{
  "title":   "Radar chart",
  "caption": "With a caption",
  "type":    "radar",
  "options": {
	"legend":  true,
    "labels":  true,
    "numbers": true
  },
  "data": [
    {
		"label": "iPhone",
		"value": [64, 23, 45, 34, 52, 43, 59, 40],
		"points": [
			"Features",
			"Style",
			"Usability",
			"Ratings",
			"Apps",
			"Softness",
			"Ruggedness",
			"Appeal"
		]
	},
	{
		"label": "Android",
		"value": [86, 53, 55, 66, 80, 46, 49, 40]
	},
	{
		"label": "Chrome",
		"value": [100, 35, 76, 90, 36, 9, 0, 90]
	}
  ]
}
```

## Raw code

```json
{
  "title":   "Radar chart",
  "caption": "With a caption",
  "type":    "radar",
  "options": {
	"legend":  true,
    "labels":  true,
    "numbers": true
  },
  "data": [
    {
		"label": "iPhone",
		"value": [64, 23, 45, 34, 52, 43, 59, 40],
		"points": [
			"Features",
			"Style",
			"Usability",
			"Ratings",
			"Apps",
			"Softness",
			"Ruggedness",
			"Appeal"
		]
	},
	{
		"label": "Android",
		"value": [86, 53, 55, 66, 80, 46, 49, 40]
	},
	{
		"label": "Chrome",
		"value": [100, 35, 76, 90, 36, 9, 0, 90]
	}
  ]
}
```
