# **charty** plugin<br>for docsify.js :id=main

Add some charts to your life

[Read more &nbsp; &darr;](#docsify-charty)<br>
<br>
[Github](https://github.com/markbattistella/docsify-charty)
[npmjs](https://www.npmjs.com/package/@markbattistella/docsify-charty)
