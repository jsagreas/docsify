
![logo](doc/cover.svg)

# docsify-mustache&nbsp;

> Preprocessing markdown documents with Mustache

- On the fly preprocessing documents
- Mustache variables in markdown
- Variables from JSON and XML 
- Variables from front matter

[Get Started](#docsify-mustache)
[GitHub](https://github.com/docsify-mustache/docsify-mustache.github.io)
