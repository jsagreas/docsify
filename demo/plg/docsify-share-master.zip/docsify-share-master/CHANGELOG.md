# Changelog

All notable changes to `docsify-share` will be documented in this file

## 0.1.1 - 2020-05-15

- update documentation
- fix undefined bug in previous version

## 0.1.0 - 2020-05-15

- major refactoring code
    - add theme feature
        - default
        - open-window
        - side-bar
    - add color feature

## 0.0.3 - 2020-05-14

- update documentation

## 0.0.2 - 2020-05-14

- refactoring docsify-share typescript

## 0.0.1 - 2020-05-13

- initial release
- simple share button
