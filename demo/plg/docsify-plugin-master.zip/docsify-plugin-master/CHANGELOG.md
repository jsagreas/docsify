# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

## [0.3.0](https://github.com/anikethsaha/docsify-changelog-plugin/compare/v0.2.0...v0.3.0) (2020-02-11)



## [0.2.0](https://github.com/anikethsaha/docsify-changelog-plugin/compare/v0.1.0...v0.2.0) (2020-02-11)


### Bug Fixes

* major fix and added docs ([af58522](https://github.com/anikethsaha/docsify-changelog-plugin/commit/af58522))



## 0.1.0 (2020-02-11)
