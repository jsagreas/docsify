# Change Log

## 1.0.0

_2019-07-24_

-   Initial Release

## 1.1.0

_2020-05-26_

-   Fix a markdown bug
-   Update dependency packages