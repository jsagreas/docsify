# Change Log

## 1.0.2

*2022-08-16*

- Fix notebook init only first page load

## 1.0.1

*2022-07-28*

- Update README.md

## 1.0.0

*2022-07-14*

- Initial release
