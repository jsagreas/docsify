# Glossary

## A

### Admiral

A commander of a fleet or naval squadron, or a naval officer of very high rank.

## B - I

Nothing here....

## J

### Jack Rackham

Jack Rackham was a gentleman pirate with flamboyant fashion sense and a way with female pirates who were dressed like men– notably, Anne Bonny and Mary Read.


## K - X

## Y

### Yellow Jack

Another term for yellow flag
