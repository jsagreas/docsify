module.exports = {
  plugins: [
    require('cssnano'),
  ],
}
