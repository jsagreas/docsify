- Chapter 1

    - [Home](/)
    - [Foo](chapter-1/foo.md#section-3)
    - [Bar A Long Long Long Title](chapter-1/bar.md)
    - [Baz](chapter-1/baz.md)

- Chapter 2

    - [Foo](chapter-2/foo.md)
    - [Bar](chapter-2/bar.md)
    - [Baz](chapter-2/baz.md)

- Chapter 3

    - [Foo](chapter-3/foo.md)
    - [Bar](chapter-3/bar.md)
    - [Baz](chapter-3/baz.md)
