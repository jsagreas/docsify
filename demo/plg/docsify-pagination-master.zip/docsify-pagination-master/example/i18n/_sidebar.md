- Chapter 1

    - [Home](/)
    - [Bar A Long Long Long Title](/chapter-1/bar.md)

- Chapter 2

    - [Foo](/chapter-2/foo.md)
    - [Baz](/chapter-2/baz.md)
