- 章节 1

    - [首页](/zh-cn/)
    - [中文 Bar 很长很长的标题](/zh-cn/chapter-1/bar.md)

- 章节 2

    - [中文 Foo](/zh-cn/chapter-2/foo.md)
    - [中文 Baz](/zh-cn/chapter-2/baz.md)
