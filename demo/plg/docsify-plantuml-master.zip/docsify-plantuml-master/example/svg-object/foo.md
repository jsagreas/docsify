# foobar

```plantuml
@startuml
Alice -> Bob: Authentication Request [[$./ docs]]
@enduml
```
