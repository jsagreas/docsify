# Change Log

## 2.1.0

*2019-01-23*

- Added localization (l10n) support via `copyCode` options
- Added error feedback (UI & console)
- Added demo site
- Fixed success feedback in IE
- Updated README
- Updated dependencies

## 2.0.2

*2018-04-16*

- Updated plugin bundling configuration
- Removed necessity for `init()` method
- Removed external stylesheet

## 1.0.0

*2017-09-28*

- Initial release
