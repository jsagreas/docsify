# Change Log 

#### Version 0.2.1 - 7/24/2019
- Documentation updates
- Fixed a bug where wide GIFs would push outside of the container bounds - [#1](https://github.com/gbodigital/docsify-gifcontrol/issues/1)

#### Version 0.2.0 - 7/24/2019
- Icon customization
- Click to play option (instead of hover)
- Error state properly displays when file load fails
- Customizable error message added
- Icon and background color customization options
- Fixed a bug with the sizing of the overlays
- Major documentation updates with examples
- Added Babel and IE11 support
- Removed unused dependencies

#### Version 0.1.0 - 7/23/2019
- Initial release, things are still very rough around the edges