# Footer Plugin for Docsify

## Example

Text
Text

1. More Text
2. More Text
