## relative path
[[otherFile | other file in subPath]]  
## absolute path
[[/]]  
[[/fileName]]  
a
b