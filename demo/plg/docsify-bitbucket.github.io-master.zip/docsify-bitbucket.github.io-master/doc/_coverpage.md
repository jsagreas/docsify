
![logo](doc/cover.svg)

# docsify-bitbucket&nbsp;

> Make easier to use Docsify with Bitbucket

- Simple linking between repositories
- Automatic repository URL detection
- Document favicon from Bitbucket
- Document logo from Bitbucket
- Bitbucket corner icon

[Get Started](#docsify-bitbucket)
[GitHub](https://github.com/docsify-bitbucket/docsify-bitbucket.github.io)
