# Docsify Image Caption

**docsify-image-caption** is a simple plugin to show the title/caption of image.

More details can be found in [docs](https://h-hg.github.io/docsify-image-caption).
