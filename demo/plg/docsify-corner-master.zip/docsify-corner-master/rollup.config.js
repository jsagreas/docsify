module.exports = {
  input: 'src/index.js',
  output: {
    file: 'dist/docsify-corner.js',
    format: 'cjs'
  }
}
