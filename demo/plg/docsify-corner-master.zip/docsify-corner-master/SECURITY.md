# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| latest   | :white_check_mark: |

## Reporting a Vulnerability

 :email: Send me a mail . 
