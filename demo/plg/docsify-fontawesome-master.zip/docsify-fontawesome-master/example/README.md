# FontAwesome plugin for Docsify

## Example

Code:

<pre v-pre="" data-lang="md" class="language-md">
<code class="lang-md language-markdown">&#58;fas fa-home fa-fw:
&#58;fas fa-th-list fa-fw red:
&#58;fab fa-linux fa-fw blue:
&#58;fab fa-aws fa-fw orange:
</code></pre>

Result:

:fas fa-home fa-fw:
:fas fa-th-list fa-fw red:
:fab fa-linux fa-fw blue:
:fab fa-aws fa-fw orange:
