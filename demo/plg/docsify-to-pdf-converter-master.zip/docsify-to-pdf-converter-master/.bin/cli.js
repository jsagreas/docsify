#!/usr/bin/env node

const rcfile = require("rcfile");

const config = rcfile("docsifytopdf");

require("../src/index.js")(config);
