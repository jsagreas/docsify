##### Admiral
a commander of a fleet or naval squadron, or a naval officer of very high rank.

##### Yellow Jack
another term for yellow flag