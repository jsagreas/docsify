# Playwright Adapter

The 3rd party [Playwright](https://playwright.dev/) adapter is provided by [@gribnoysup](https://github.com/redabacha). Please follow the readme below for installation and usage instructions.

[README.md](https://raw.githubusercontent.com/redabacha/polly-adapter-playwright/master/README.md ':include :type=markdown')
