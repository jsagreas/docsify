export default [
  'GET',
  'PUT',
  'POST',
  'DELETE',
  'PATCH',
  'MERGE',
  'HEAD',
  'OPTIONS'
];
