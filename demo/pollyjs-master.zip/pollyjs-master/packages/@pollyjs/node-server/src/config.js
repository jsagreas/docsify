export default {
  port: 3000,
  quiet: false,
  recordingSizeLimit: '50mb',
  recordingsDir: 'recordings',
  apiNamespace: '/polly'
};
