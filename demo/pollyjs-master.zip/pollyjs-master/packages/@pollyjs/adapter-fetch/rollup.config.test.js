import createBrowserTestConfig from '../../../scripts/rollup/browser.test.config';

export default [createBrowserTestConfig()];
