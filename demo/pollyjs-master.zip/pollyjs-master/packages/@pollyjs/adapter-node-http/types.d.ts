import Adapter from '@pollyjs/adapter';

export default class NodeHttpAdapter extends Adapter {}
