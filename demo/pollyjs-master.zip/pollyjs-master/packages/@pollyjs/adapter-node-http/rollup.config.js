import createNodeConfig from '../../../scripts/rollup/node.config';

import { external } from './rollup.config.shared';

export default createNodeConfig({ external });
