import Adapter from '../../src';

describe('Unit | Adapter', function () {
  it('should exist', function () {
    expect(Adapter).to.be.a('function');
  });
});
