'use strict';

module.exports = function () {
  return {};
};
