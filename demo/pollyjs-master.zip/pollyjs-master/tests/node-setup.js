/* eslint-env node */

global.expect = require('chai').expect;
