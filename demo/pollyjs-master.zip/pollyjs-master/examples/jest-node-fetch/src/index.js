module.exports = {
  posts: require('./posts'),
  users: require('./users')
};
