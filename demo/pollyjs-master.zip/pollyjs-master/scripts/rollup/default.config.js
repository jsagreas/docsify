import createBrowserConfig from './browser.config';
import createNodeConfig from './node.config';

export default [createBrowserConfig(), createNodeConfig()];
