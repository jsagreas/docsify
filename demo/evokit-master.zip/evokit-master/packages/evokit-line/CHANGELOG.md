[README]: /packages/evokit-line/README.md
[evokit]: /packages/evokit/README.md

# EvoKit - Line

[![](https://img.shields.io/npm/v/evokit-line.svg)](https://www.npmjs.com/package/evokit-line)
[![](https://img.shields.io/badge/page-README-42b983)][README]

---

## CHANGELOG

### 3.1.0 *(11.10.2019)*

- **Updated** peer dependencies [`evokit`][evokit] >= **v3.1.0**

### 3.0.1

- **Added** new prop `line-display`
- **Added** new value `solid` for prop `line-style`

### 3.0.0

- Initial version independent package. The [previous changelog](/packages/evokit/CHANGELOG.md) in another package.
