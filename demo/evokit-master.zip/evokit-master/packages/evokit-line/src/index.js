import { createBlock } from 'evokit';

export const Line = createBlock('hr', 'line', [
    'display',
    'indent',
    'style',
    'color',
]);
