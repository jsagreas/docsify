import { List } from 'evokit-list';
import './style.css';

export { List };
