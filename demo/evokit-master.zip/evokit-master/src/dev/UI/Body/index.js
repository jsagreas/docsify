import { Body } from 'evokit-body';
import 'evokit-body/style.css';

export { Body };
