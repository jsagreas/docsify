import { Image } from 'evokit-image';
import './style.css';

export { Image };
