import { Picture } from 'evokit-picture';
import 'evokit-picture/style.css';

export { Picture };
