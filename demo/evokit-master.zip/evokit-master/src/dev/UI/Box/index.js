import { Box } from 'evokit-box';
import './style.css';

export { Box };
