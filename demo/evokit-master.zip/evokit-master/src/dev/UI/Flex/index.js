import { Flex } from 'evokit-flex';
import 'evokit-flex/style.css';

export { Flex };
