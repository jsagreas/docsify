import { Button } from 'evokit-button';
import './style.css';

export { Button };
