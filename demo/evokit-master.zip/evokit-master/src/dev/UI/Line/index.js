import { Line } from 'evokit-line';
import 'evokit-line/style.css';

export { Line };
