import { Text } from 'evokit-text';
import 'evokit-text/style.css';

export { Text };
