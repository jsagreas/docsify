import { Link } from 'evokit-link';
import 'evokit-link/style.css';

export { Link };
