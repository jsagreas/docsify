import { createBlock } from 'evokit';

export const ${BLOCK_NAME_CAPITALIZE} = createBlock('div', '${BLOCK_NAME}', [
    'display',
]);
