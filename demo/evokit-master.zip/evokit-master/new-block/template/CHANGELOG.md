[README]: /packages/${PACKAGE_NAME}/README.md


# EvoKit - ${BLOCK_NAME_CAPITALIZE}

[![](https://img.shields.io/npm/v/${PACKAGE_NAME}.svg)](https://www.npmjs.com/package/${PACKAGE_NAME})
[![](https://img.shields.io/badge/page-README-42b983)][README]

---

## CHANGELOG

### ${PACKAGE_VERSION}

- Initial version.
