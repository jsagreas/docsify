module.exports = require('../../config/jest.config.js');
