<!-- _coverpage.md -->

![logo](docs/_media/logo.svg?ua)

# [EvoKit](/)

[![](https://img.shields.io/npm/v/evokit.svg?style=flat-square&colorB=blue)](https://www.npmjs.com/package/evokit)

> Русский мир - иди нахуй!

* СЛАВА УКРАЇНІ! ГЕРОЯМ СЛАВА!

[GITHUB](https://github.com/docccdev/evokit)
[README](/docs/getting-started/introduction.md)
