#!/bin/bash

set -e

echo -n 'Starting server...' && node server.js
