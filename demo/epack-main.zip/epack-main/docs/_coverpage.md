# `epack`

> A simple to use GUI interface that provides an easier way to make extensions

- Simply in the browser
- Supports multiple extension components
- Easy to develop with

[GitHub](https://github.com/Yash-Singh1/epack/)
[Get Started](?id=main)
<a href="/playground/">Playground</a>

<!-- background color -->

![color](#edc7c7)
