- Introduction

  - [Getting Started](README.md)
  - [Setting Up](setup.md)
  - [Navigating Site](ui.md)

- Contributing

  - [Contributing Guidelines](CONTRIBUTING.md)
  - [Roadmap](ROADMAP.md)
  - [Code of Conduct](CODE_OF_CONDUCT.md)

- MonkeyIDE

  - [About](MONKEYIDE_README.md)
  - [License](MONKEYIDE_LICENSE.md)

- Advanced

  - [Events](advanced/events.md)
  - [Sidebars](advanced/sidebars.md)
  - [DevTools Script](advanced/devtools-script.md)
  - [Architecture](ARCHITECTURE.md)

- [License](LICENSE.md)
