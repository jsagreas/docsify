# Roadmap

This is the roadmap for `epack`:

- Create an action to export the extension
