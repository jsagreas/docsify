In short, you're tied in to native proxy settings.

There are no proxy forwarders only analysers.
