## Systems

<div id="linked-areas">

[<i class="i-windows"></i> Windows](/proxy/windows ':class=mb-button')
[<i class="i-macos"></i>macOS](/proxy/macOS ':class=mb-button')
[<i class="i-linux"></i>Linux](/proxy/linux ':class=mb-button')
[<i class="i-ios"></i>iOS / iPadOS](/proxy/ios ':class=mb-button')
[<i class="i-android"></i>Android](/proxy/android ':class=mb-button')
[<i class="i-apps"></i>Applications](/proxy/apps ':class=mb-button')
[<i class="i-helper"></i>Helpers](/proxy/helper ':class=mb-button')

</div>

<a href="/" class="mb-button" style="background:#00b894;"><i class="i-home"></i>Home</a>
