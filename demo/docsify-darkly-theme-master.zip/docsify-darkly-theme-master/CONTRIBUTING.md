# Fork Repo
- [Fork](https://github.com/sushantrahate/docsify-darkly-theme/fork) the repository 
- `git clone https://github.com/${yourUsername}/docsify-darkly-theme`
- `cd docsify-darkly-theme`
- Make changes in CSS File`docs/css/darkly.css` and preview it. later do the same changes in `css/darkly.css` and `css/darkly.min.css` folder of root dir and Create Pull Request

# Sending Pull Request
- Create a branch in your forked repository with a relevant name (`e.g enhanced-styling`)
- Push your changes to the branch
- Create a pull request from your branch to `master` of my branch.
