const COMMON = require('../../../scripts/jest/common.config');

module.exports = {
    displayName: 'console-stream',
    ...COMMON,
};
