const COMMON = require('../../../scripts/jest/common.config');

module.exports = {
    displayName: 'builder',
    ...COMMON,
};
