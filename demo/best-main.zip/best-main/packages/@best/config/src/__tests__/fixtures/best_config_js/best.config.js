module.exports = {
    projectName: 'test',
};
